import java.util.ArrayList;
import java.util.Random;

public class Enemy extends Fighter {

	 private static Random Rand = new Random();
	  public Enemy(String n,int[] s, ArrayList<Integer> m, ArrayList<Integer> in)
	  {
	  	 super(n,s,m,in);  
		 Name = n;
	  }
	  public void choose(String[] p,String d,int b)
	  {
	    int c = Rand.nextInt(Moveset.size());
		c = Moveset.get(c);
	     if(c == 1)
	     {
	       NextAttack = new Guard("Guard",MovePool.getMove(c).getIns(),0," is no longer being stared at.");     	  
	       c = Rand.nextInt(10);
	       NextAttack.initiate(c,Stats[4]);
	     }
	     else if(c == 0)
	     {
	     	NextAttack = new Bash("Bash",MovePool.getMove(c).getIns(),0,"was hit");   	  
	     	c = Rand.nextInt(50);
	     	NextAttack.initiate(c,Stats[4]);
	     }
	     else
	     {
	    	 NextAttack = MovePool.getMove(c);
	     }
	     Target = Rand.nextInt(b);
	     if(NextAttack instanceof Item)
	     {
	       Inventory.remove(c);
	     }
	  }
}
