import java.util.ArrayList;
public class FightClub {

	  private static int[][] st = StatsLoad();
	  private static int[][] mv = LoadMoves();
	  public static Fighter[] fighters = ConstructF();
	 public static int[][] LoadMoves()
	  {
	    int[][] m =
	    {{30,2,4,13,28,31,22,14},{8,3,21,23,10,18,30,17},{22,10,18,29},{22,10,18,29},{27,26,25},{19,20,10,0,29},{30,3,0,29},{12,11,15,16},{30,3,0,8,21}};
	    
	    return m;
	  }
	 public static ArrayList<Integer> mvLoad(int i)
	 {
		 ArrayList<Integer> in = new ArrayList<Integer>();
		 for(int i2 = 0;i2<mv[i].length;i2++)
		 {
			 in.add(mv[i][i2]);
		 }
		 return in;
	 }
	  public static int[][] StatsLoad()
	  {	 
		int[][] r = {{600,0,0,0,0,600,0,100,100,40},
					 {800,0,0,0,0,800,0,120,120,30},  
		             {500,0,0,0,0,500,0,90,80,40},
		             {500,0,0,0,0,500,0,110,90,40},
		             {2000,0,0,0,0,2000,0,80,150,20},
		             {400,0,0,0,0,400,0,90,70,40},
		             {1200,0,0,0,0,1200,0,175,100,50},
		             {1000,0,0,0,0,1000,0,70,180,35},
		             {2000,0,0,0,0,2000,0,150,150,30}};		             		                 
		System.out.println("Stats check");
		return r;
	  }
	  
	  public static Fighter[] ConstructF()
	  {
		String[] nm = {"Xavier","Rick","Stanley","Stanley","Mean-Bean-Machine Operator","Hood Rat","Incredibly Fit Scruffy Old Man","Angry Traffic Officer","Alpha-Rick"};
		Fighter[] f = new Fighter[9];
		ArrayList<Integer> in = new ArrayList<Integer>();
		in.add(7);
		in.add(7);
		in.add(6);
		in.add(6);
		in.add(9);
		in.add(9);
		in.add(24);
		
		for(int i = 0;i<9;i++)
		{
			
			if(i<3)
			f[i] = new Ally(nm[i],st[i],mvLoad(i),in);
			else
			f[i] = new Enemy(nm[i],st[i],mvLoad(i),in);	
		}
		
	    return f;                        
	  }
	    public static Fighter getFighter(int i)
	  {
	    return 	fighters[i];
	  }  
	}


