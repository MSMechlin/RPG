

public class Item extends Move {

	  public Item(String n,int[][] in, int c,String s)  
	  {
	    super(n,in,c,s);
	  }
	  public void initiate(int s,int c)
	  {
	  } 

}
