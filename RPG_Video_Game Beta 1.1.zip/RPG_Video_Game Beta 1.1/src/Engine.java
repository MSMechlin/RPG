import java.util.Scanner;
import java.util.Random;
class Event
{
	private static int[][] e = loadE();
	public static int[][] loadE()
	{
		int[][] e1 = {{3},{4},{5,5,5},{6},{7},{0,2},{8}};
		return e1;
	}
	public static int[] getEvent(int i)
	{
		return e[i];
	}
}
class Utility
{
  private static Operation[] Operations = loadOps();
  public static Operation getOps(int i)
  {
    return Operations[i];
  }
  public static Operation[] loadOps()
  {
    Operation[] r = new Operation[5];
    r[0] = new NullOp();
    r[1] = new PowXRatio();
    r[2] = new FixedDamage();
    r[3] = new PercentOfU();
    r[4] = new PercentOfT();
	 return r;    
  }
  public static void arrPrint(String[] p)
  {
	for(int i = 0;i<p.length;i++)
	{
		System.out.println(i + ". " + p[i]);
	}	
  }
}
abstract class Operation
{
  abstract public int calculate(int a,int b,int c);
}
class NullOp extends Operation
{
  public int calculate(int a,int b,int c)
  {
    return 0;
  }
}
class PowXRatio extends Operation
{
  public int calculate(int a,int b,int c)
  {    
    return (((100*b)/c)*a)/100;
  }
}
class FixedDamage extends Operation
{
  public int calculate(int a,int b,int c)
  {
    return a;
  }
}
class PercentOfU extends Operation
{
  public int calculate(int a,int b,int c)
  {
    return (a*b)/100;
  }
}
class PercentOfT extends Operation
{
  public int calculate(int a,int b,int c)
  {
    return (a*c)/100;
  }
}

class complexDriver {
	  	public static void main(String[] args)
	  	{
	  		Scanner s = new Scanner(System.in);
	  		Random rand = new Random();
	  		String next = "0";
	  		String ans = "";
	  		int[] a = {0};
	  		Party party = new Party(a);
	  			  			  			  		
	  		boolean manag = false;	  		
	  		boolean b;
	  		while(true) {
	  			switch(next)
	  			{
	  				case "D":
	  					System.out.println("**You were defeated in battle! That's game over, bub.** \n\nInput \"y\" to start over.");
	  					ans = s.nextLine();
	  					while(!ans.equals("y"))
	  					{
	  						System.out.println("Input \"y\" to start over.");
	  						ans = s.nextLine();
	  					}
	  					break;
	  				case "0":
	  					System.out.println("\"Get up, or I'll beat you upside the head.\" You quickly come to your senses and realize you fell asleep while working." +
	  											 "\nAgain. Your shift started 10 minutes ago and you were already asleep. What a stand up kind of guy you are. Anyway," +
	  											 "\nyou get up off the floor and your manager, Rick Steves, is standing right in front of you. What do you say to him?" +
	  											 "\n\n[1] Apologize politely\n[2] Apologize aggressively\n[3] Punch Rick's dumb face");
	  					ans = s.nextLine();
	  					while(true) {
	  						if(ans.equals("1") || ans.equals("2") || ans.equals("3"))
	  						{
	  							if(ans.equals("1")) {
	  								next = "1A";
	  							}
	  							else if(ans.equals("2")) {
	  								next = "1B";
	  							}
	  							else if(ans.equals("3")) {
	  								next = "1C";
	  							}
	  							break;
	  						}
	  						else
	  						{
	  							System.out.println("You can't do something that isn't an option, dingus.");
	  							ans = s.nextLine();
	  						}		 
	  					}
	  					break;
	  				
	  				case "1A":
	  					System.out.println("\nYou tell the manager that you're sorry and you had a rough day. He nods in understanding and leaves you to your duties.");
	  					next = "2";
	  					break;
	  				case "1B":
	  					System.out.println("\nYou violently curse at your manager. Before he has a chance to fire you, you're storming out.");
	  					manag = true;
	  					next = "2";
	  					break;
	  				case "1C":
	  					System.out.println("You lunge at your manager with your fist out. As it is about to hit his dumb, stupid face, he grabs your arm and" +
	  											 "\nslams you to the ground. \"Are you looking for a fight, squirt?\" He takes you to the front door and kicks you out."+
	  											 "\nYou're pretty sure you won't be working there again." +
	  											 "\n\nEnter \"y\" to try again.");
	  					ans = s.nextLine();
	  					switch(ans)
	  					{
	  						case "y":
	  							next = "0";
	  					}
	  					break;
	  				case "2":
	  					System.out.println("\nYou enter key room so you can get to driving your truck, only to find that they aren't there. Stanley, who" +
	  											 "\nstarted working here a few days ago, is standing by your locker. You decide to inquire him about the keys." +
	  											 "\n\"Oh, these? Sorry bub, these are mine now. What are you gonna do, fight me?" + 
	  											 "\n\n[1]Bring it, guy!" +
	  											 "\n[2]I'm good.");
	  					ans = s.nextLine();
	  					while(true) {
	  						if(ans.equals("1") || ans.equals("2"))
	  						{
	  							if(ans.equals("1")) {
	  								next = "2A";
	  							}
	  							else if(ans.equals("2")) {
	  								next = "2B";
	  							}
	  							break;
	  						}
	  						else
	  						{
	  							System.out.println("You can't do something that isn't an option, dingus.");
	  							ans = s.nextLine();
	  						}		 
	  					}
	  					
	  					break;
	  				case "2A":
	  					System.out.println("Look, Xavier, you're tough. But you can't match these guns!");
	  					
	  					if(party.Battle(Event.getEvent(0))) {
	  						next = "3";
	  					}
	  					else {
	  						next = "D";
	  					}
	  					break;
	  				case "2B":
	  					System.out.println("Really? You don't want your keys? How will you like, work? Are you sure?\n[1]Yes [2]No");
	  					ans = s.nextLine();
	  					while(!ans.equals("2"))
	  					{
	  						System.out.println("Really?");
	  						ans = s.nextLine();
	  					}
	  					System.out.println("That's right. Now fight me, opiods!");
	  					//battle vs stanley////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	  					if(party.Battle(Event.getEvent(0))) {
	  						next = "3";
	  					}
	  					else {
	  						next = "D";
	  					}
	  					break;
	  				case "3":
	  					System.out.println("\nHaving obtained the keys from your friendly and cooperative coworker, you head towards the truck." +
	  											 "\nDriving away from the facility, you come to a forked road. The path on the left has a sign that" +
	  											 "\nreads, \"The path you always go on. If I were a sentient being, I would probably choose this path.\"" +
	  											 "\nTo the right has no sign and is fairly rough, the road is too, You aren't sure if the suspension will hold up.");
	  					System.out.println("\nWill you go left, or right?\n\n[1]Left\n[2]Right");
	  					ans = s.nextLine();
	  					while(true) {
	  						if(ans.equals("1") || ans.equals("2"))
	  						{
	  							if(ans.equals("1")) {
	  								next = "3A";
	  							}
	  							else if(ans.equals("2")) {
	  								next = "3B";
	  							}
	  							break;
	  						}
	  						else
	  						{
	  							System.out.println("You can't do something that isn't an option, dingus.");
	  							ans = s.nextLine();
	  						}
	  					}				 
	  					break;
	  				case "3A":
	  					System.out.println("\nDeciding to take the safe route, you prove to be an incredibly boring person. You drive to the usual houses," +
	  											 "\ndeliver the usual mail, and run from the usual dogs. When you get back, your boss decides to fire you for" +
	  											 "\nbeing such an incredibly uninteresting man.\n\nInput \"y\" to try again.");
	  					while(true)
	  					{
	  						ans = s.nextLine();
	  						if(ans.equals("y")) {
	  							next = "3";
	  							break;
	  						}
	  					}
	  					break;
	  				case "3B":
	  					System.out.println("\nYou decide to take the path to the right. Almost immediately you notice that the road is throwing you around" +
	  											 "\nyour truck like Ric Flair. Your worries about the suspension were all but true, and you have to pull over." +	
	  											 "\nPulling over to the side, you realize that there is no help in sight. As far as you could tell, there was nobody" +
	  											 "\nanywhere ahead of you. You decide to turn around. In doing so, a wheel literally rattles off and " +
	  											 "\nyou feel the truck scraping the dirt road. Nice going, blockhead. Now what are you going to do?"+
	  											 "\n\n[1] Sit and wait for a bypasser\n[2] Start walking back towards town\n[3] Keep trekking forward");
	  					ans = s.nextLine();
	  					while(true) {
	  						if(ans.equals("1") || ans.equals("2") || ans.equals("3"))
	  						{
	  							if(ans.equals("1")) {
	  								next = "4.1";
	  							}
	  							else if(ans.equals("2")) {
	  								next = "3BD";
	  							}
	  							else if(ans.equals("3")) {
	  								next = "4.2";
	  							}
	  							break;
	  						}
	  						else
	  						{
	  							System.out.println("You can't do something that isn't an option, dingus.");
	  							ans = s.nextLine();
	  						}
	  					}
	  					break;
	  				case "3BD":
	  					System.out.println("\nYou start walking back towards town. Soon enough, you're back at the fork in the road and can see the loading station." +
	  											 "\nAny feelings of relief are squashed when you see your manager in a black Benz rolling towards you. He rolls down his" +
	  											 "\nwindow. \"What the hell are you doing out here?\" he shouts at you. You explain your situation.");
	  					if(manag)
	  					{
	  						next = "3BDB";
	  					}
	  					else
	  					{
	  						next =  "3BDA";
	  					}
	  					break;
	  				case "3BDB":
	  					System.out.println("\nRick nods. He pulls out his phone and seems to be calling a tow truck until he suddenly throws you a grimace." +
	  											 "\n\"Oh, about those things you said to me earlier...\" You gulped. You remember the slamming that you gave him" +
	  											 "\n...just 30 minutes before. \"You're fired.\" Before you know it, he's rolling away.\n\nYou fall to your knees. It seems your adventure ends here." +
	  											 "\n\nInput \"y\" to try again");
	  					ans = s.nextLine();
	  					while(!ans.equals("y"))
	  					{
	  						ans = s.nextLine();
	  					}
	  					next = "0";
	  					break;
	  				case "3BDA":
	  					System.out.println("\n\"So you took the path on the right and your wheel fell off? You should have known this would happen, guy.\" " +
	  				 						  "\nHe tells you to get in the Benz and you head towards the truck.");
	  					next = "4.2";
	  				 	break;
	  				case "4.1":
	  					System.out.println("\nYou decide to wait for someone to pass by. After about 5 hours of waiting, it seemed nobody would be coming to help you." +
	  											 "\nYou could have just walked back 5 minutes to the facility, but you were too lazy. Anywho, your boss ends up driving\n" +
	  											 "down the road to look for you. Lucky. He pulls over by your truck. \"Why in heck's name would you go down this path, guy?" +
	  											 "\nNot having an answer for him, he gets out of and checks out the damage.");
	  					next = "4";
	  					break;
	  				case "4.2":
	  					System.out.println("\nYou decide to keep on trucking forward. You get the mail from the truck and sling it on your back, ready to take on your\n" +
	  											 "duties. After about 10 minutes of walking, your frail legs get to you and you have to take a break on some logs. However, " +
	  											 "\nthere was a lean mean bean machine under there! \n\nInput \"y\" to enter the fight.");
	  					ans = s.nextLine();
	  					while(!ans.equals("y"))
	  					{
	  						System.out.println("Input \"y\" to enter the fight.");
	  						ans = s.nextLine();
	  					}
	  					//battle against lean mean bean machine
	  					
	  					if(party.Battle(Event.getEvent(1))) {
	  						System.out.println("Having defeated the lean mean bean machine, you decide to head back. This wasn't such a good idea.");
	  						next = "4.1";
	  					}
	  					else {
	  						next = "D";
	  					}
	  					break;
	  				case "4":
	  					party.induct(1);
	  					System.out.println("\n**Rick has joined your party!**\n\n\"Looks rough,\" Rick says. \"Look, there's nobody towing trucks at this hour.\"" +
	  											 "\nFeeling bad, you decide to sit down and think about your actions up to this point. Why did you even become a mail" +
	  											 "\ndelivery driver to begin with? You pause your thinking as a LOUD BAND OF HOOLIGANS appear, driving down the road." +
	  											 "\n\nBrace yourself by inputting \"y\"!"); 
	  					ans = s.nextLine();
	  					while(!ans.equals("y"))
	  					{
	  						System.out.println("Brace yourself by inputting \"y\"!");
	  						ans = s.nextLine();
	  					}
	  					if(party.Battle(Event.getEvent(2)))	
	  					next = "5";
	  					else
	  					next = "D";	
	  					break;
	  				case "5":
	  					System.out.println("\nHaving successfully beat the hoodlums, you get back to business.\"Hey, look what I found, sap!\" He pulls" +
	  											 "\na tire out from behind him. You ask him where he found it. \"That's not important. Anyway, let's get moving." +
	  											 "\nAfter all, you have a job to do! You start making away towards your usual route for the day. Unforunately," +
	  											 "\nyour boss decides to stay with you. Pulling up to the first house of the day, you notice that the man's door" +
	  											 "\n has been left open. \"Don't worry about it, dude. \" says your boss, but you're still kinda curious about" +
	  											 "\nwhat might be inside.\n\n[1]Check out the house \n[2]Keep on trucking");
	  					ans = s.nextLine();
	  					while(true) {
	  						if(ans.equals("1") || ans.equals("2"))
	  						{
	  							if(ans.equals("1")) {
	  								next = "5A";
	  							}
	  							else if(ans.equals("2")) {
	  								System.out.println("You decide that Rick's right. It would be dumb to intrude on someone's house.\n\n");
	  								next = "6";
	  							}
	  							break;
	  						}
	  						else
	  						{
	  							System.out.println("You can't do something that isn't an option, dingus.");
	  							ans = s.nextLine();
	  						}
	  					}
	  					break;
	  				case "5A":
	  					System.out.println(
	  											 "You head up to the front door, which is still ajar. You yell to see if anyone is in there. You put one step" +
	  											 "\nthrough the door and suddently, and INCREDIBLY FIT GRUFFY OLD MAN grabs you by the shoulders and pulls you in!" +
	  											 "\nRick comes running in after you.\n\nInput \"y\" to fight an old man!");
	  					
	  					ans = s.nextLine();
	  					while(!ans.equals("y"))
	  					{
	  						System.out.println("Input \"y\" to fight an old man!");
	  						ans = s.nextLine();
	  					}
	  					
	  					if(party.Battle(Event.getEvent(3))) {
	  						next = "6";
	  					}
	  					else {
	  						next = "D";
	  					}
	  					System.out.println("\nLeaving the home scarred, you get back to work and you both get in the truck. Nice going.");
	  					
	  					break;
	  				case "6":
	  					System.out.println("\nContinuing the daily grind, you drive down the road and see an incredibly big pile up by the intersection." +
	  											 "\nIt looks like you'll have to find another way.\n\n[1]Sit and wait for it to clear\n[2]Drive through it");
	  					ans = s.nextLine();
	  					while(true) {
	  						if(ans.equals("1") || ans.equals("2"))
	  						{
	  							if(ans.equals("1")) {
	  								next = "6D";
	  							}
	  							else if(ans.equals("2")) {
	  								next = "6A";
	  							}
	  							break;
	  						}
	  						else
	  						{
	  							System.out.println("You can't do something that isn't an option, dingus.");
	  							ans = s.nextLine();
	  						}
	  				  }
	  				  break;
	  				case "6D":
	  					System.out.println("You decide to sit and wait, finding that it would simply be too reckless to just power through the line of cars." +
	  											 "\n\nYou end up waiting for a while. In fact, you waited for so long that eventually, you both died of old age.\n\n" +
	  											 "Input \"y\" to try again");
	  					ans = s.nextLine();
	  					while(!ans.equals("y"))
	  					{
	  						System.out.println("Input \"y\" to try again");
	  						ans = s.nextLine();
	  					}
	  					next = "6";
	  					break;
	  				case "6A":
	  					System.out.println("\nYou decide that it's best if you slam through hundreds of cars to deliver a few pieces of paper. Somehow, this is the" +
	  											 "\nright decision. Rick is a pretty heavy sleeper, so he probably wouldn't wake up anyway. So you floor it through the intersection" +
	  											 "\nslamming probably 30 vehicles out of the way before one brave man is able to stop you. \"You just ruined my fresh paint, " +
	  											 "\nyou whippersnappers! Rick wakes up, visibly shaken from his powerful voice.\"Prepare to face my wrath!\"\n\nPress \"y\" to face his wrath");
	  					ans = s.nextLine();
	  					//battle vs angry traffic guy
	  					while(!ans.equals("y"))
	  					{
	  						System.out.println("Press \"y\" to face his wrath");
	  						ans = s.nextLine();
	  					}
	  					if(party.Battle(Event.getEvent(4))) {
	  						next = "7";
	  					}
	  					else {
	  						next = "D";
	  					}
	  					
	  					break;
	  				case "7":
	  					System.out.println("Having defeated the heated man, you both decide that it would be best if you called it a day. \"I've never seen so much action in" +
	  											 "\none day. I think I owe you a promotion.\" Heading back to the facility, passing what used to a town before you crashed through it" +
	  											 "\nYou notice that Rick is being too nice. There's no way he would ever offer anyone any sort of promotion. Something is up.\n\n" +
	  											 "\nYou head into his office when you get back and start discussing. \"Your thoughts were all true, I'm not gonna offer you a promotion," +
	  											 "\n guy. In fact, all I need from you is that magic mungus banana. The only reason I ever decided to associate with the likes of you was" +
	  											 "\n for that banana alone. That banana is the reason you have a job! Why not got to such lengths for the key to all life!\" You have a"+
	  											 "\n confused look on your face.\"You know not of the Mystic mungus Banana?\", he inquires. You shrug in a concerned fashion. \""+
	  											 "\n Why, the Mystic Mungus Banana\" is the most legendary fruit of them all! Once every hundred yea... no, thousand years a" +
	  											 "\n poor African child picks a special banana.This special banana is high in calcium so it looks funny to the child. The child asks" +
	  											 "\n his slav... employer what is up with the banana then, he gets lashed for slacking off. The tear shed by the child refracts the light "+
	  											 "\n generated from the alignment of the blue moon and Jupiter, causing the banana to become super charged with celestial powers!\"" +
	  											 "\n His story provoked so much thought that you forgot he was trying to steal your belongings.\"Alright, were is it?\"");
	  					if(Fighter.getInventory().contains(24))
	  					{
	  						next = "7F";
	  					}
	  					else
	  					{
	  						next = "7D";
	  					}
	  					break;
	  				case "7F":
	  					System.out.println("\n\"It's over, little man. Where did you put that banana?\" Still having no idea what he was talking about, you reach into your pocket and" +
	  											 "\n lo and behold, there's a banana? Whatever he meant by the \"key to all life\" You don't understand, but you know you must protect it at all costs." +
	  					
	  					                          "\n\"Gimme that banana!\" Rick exclaimed, lunging at you. \n\n**Stanley has joined the party!**\n\nEnter \"ez\" to fight your boss!");
	  					
	  					party = new Party((Event.getEvent(5)));
	  					if(party.Battle(Event.getEvent(6))) {
	  						next = "8";
	  					}
	  					else {
	  						next = "D";
	  					}
	  					s.nextLine();
	  					break;
	  				case "7D":
	  					System.out.println("\n\n\"Agh! It's not in here!\" he yelled, tossing it to the side. \"If you don't have it, then who does?\" he said, looking over at Stanley who" +
	  											 "\nwas eating just a regular banana. \"How did you...\" Rick seemed out of breath. While your boss emitted fumes toward Stanley, you decided" +
	  											 "\nto sneak out and never come back.\n\nYou failed to save the world! Enter \"getthebanana\" to try again.");
	  					ans = s.nextLine();
	  					while(!ans.equals("getthebanana"))
	  					{
	  						System.out.println("Enter \"getthebanana\" to try again.");
	  						ans = s.nextLine();
	  					}
	  					next = "0";
	  					break;
	  				case "*":
	  					System.out.println("\n\n Congrats! You defeated your Golden-banana digger of a boss. Now you're out of a job, but atleast you saved\n" 
	  											 + "the world. \n\n-----The End-----\n\nInput \"y\" to start again!");
	  					ans = s.nextLine();
	  					while(!ans.equals("y"))
	  					{
	  						System.out.println("Input \"y\" to start again!");
	  						ans = s.nextLine();
	  					}
	  					next = "0";
	  					break;
	  			}
	  		}
	  	}
	  
  }
	

