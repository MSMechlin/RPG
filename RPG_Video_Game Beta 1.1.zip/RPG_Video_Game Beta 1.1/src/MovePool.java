import java.util.ArrayList;

public class MovePool {


		  private static int[][] ins = InstructionsLoad();
		  private static Move[] movepool = loadMoves();
		 public static Move[] loadMoves()
		  {
		    Move[] m = new Move[32];
		    m[0] = new Bash("Bash",LoadIns(0),0,"");
		    m[1] = new Guard("Guard",LoadIns(1),0,"");
		    m[2] = new RegularMove("Webb Shot",LoadIns(2),100," was covered in silly string.");
		    m[3] = new RegularMove("Look Out For My Wind-up Punch!",LoadIns(3),450," was hit upside the head with a good old-fashioned wind-up punch.");
		    m[4] = new RegularMove("Zap",LoadIns(4),50," recieved a minor shock to the back of the arm.");
		    m[5] = new RegularMove("Tickle",LoadIns(5),50," started laughing profusely.");
		    m[6] = new Item("LCD Ultra 4k HD Vector Graphics Curved Screen 3D-TV-Dinner",LoadIns(6),200," ate some high quality food in high resoution.");
		    m[7] = new Item("Dr. Pepsi",LoadIns(7),100," slurped the Doc a big one.");
		    m[8] = new RegularMove("FireBall",LoadIns(8),300," was lit by a flaming ball.");
		    m[9] = new Item("Old McDonalds",LoadIns(9),200," ate a happy meal going through its mid life crisis.");
		    m[10] = new RegularMove("HeadButt",LoadIns(10),200," was headbutted savageley");		   
		    m[11] = new RegularMove("Stop Sign",LoadIns(11),50," instinctively stopped upon sight of the sign.");
		    m[12] = new RegularMove("Animal Crossing Sign",LoadIns(12),100," was trampled by crossing animals.");
		    m[13] = new RegularMove("Freeze",LoadIns(13),200," was nearly frozen solid.");
		    m[14] = new RegularMove("Lightning",LoadIns(14),400," was given a considerable less minor shock to the back of the arm.");
		    m[15] = new RegularMove("Speed Limit Sign",LoadIns(15),100," instinctively slowed to match the speed limit.");
		    m[16] = new RegularMove("Whistle",LoadIns(16),100," was startled by the abrupt noise.");
		    m[17] = new RegularMove("Pep Talk",LoadIns(17),50," was given some words of encouragement");
		    m[18] = new RegularMove("Incoherent Rambling",LoadIns(18),50," might not have understood what he said but is still terrified");
		    m[19] = new RegularMove("FreeStyle",LoadIns(19),100," was hit by a rythmic array of insults pertaining to his mother's \"conduct\".");
		    m[20] = new RegularMove("Shank",LoadIns(20),75," was jabbed with a pocket knife.");
		    m[21] = new RegularMove("Drain",LoadIns(21),100," had the life force chocked out him.");		
		    m[22] = new RegularMove("Edgy Rant",LoadIns(22),70," made everyone involed's day a little worse.");
		    m[23] = new RegularMove("Share",LoadIns(23),70," was given so uneeded life force.");
		    	m[24] = new Item("Banana",LoadIns(24),100," slipped on a banana peel and got a concusion.");
		    m[25] = new RegularMove("a Mean Bean to the Spleen",LoadIns(25),700,": \" ow, my spleen! \"");
		    m[26] = new RegularMove("a Lean Bean to the Spleen",LoadIns(26),100,": \" my spleen's seen meaner scenes\"");
		    m[27] = new RegularMove("a Green Bean to the Spleen",LoadIns(27),100,": \" turning my spleen green? That's just mean!\"");
		    m[28] = new RegularMove("Look out for my Generic, Uninspired, Run-of-the-Mill, 5/10, Mediocrity Punch...",LoadIns(28),200," was hit by a punch so painfully mediocre, it hurt more than it should have.");
		    m[29] = new RegularMove("Punch",LoadIns(29),100," was hit with a regular punch.");
		    m[30] = new RegularMove("Aerobics",LoadIns(30),50," did some stretches and a little jog in place.");
		    m[31] = new RegularMove("Heal",LoadIns(31),150," looks visibly better.");
		    
		    return m;
		  }
		  public static Move getMove(int i)
		  {
		    return movepool[i];
		  }  
		  public static int[][] LoadIns(int i)
		  {	  
			
				
			int[][] r = new int[ins[i].length/6][6];	
			
		    for(int i2 = 0;i2<ins[i].length;i2 = i2 + 6)
		    {
		    	
		      r[i2/6][0] = ins[i][i2];
		      
		      r[i2/6][1] =ins[i][i2+1];
		      
		      r[i2/6][2] =ins[i][i2+2];
		      
		      r[i2/6][3] =ins[i][i2+3];
		      
              r[i2/6][4] =ins[i][i2+4];
		      
		      r[i2/6][5] =ins[i][i2+5];
		      
		    }
		    return r;
		  }
		  public static void setPrint(ArrayList<Integer> a)
		  {
		    for(Integer m: a)
		    {
		      System.out.println(a.indexOf(m) + ". " + movepool[m].getName());
		    }
		  }   
		  public static int[][] InstructionsLoad()
		  {
		   int[][] r ={{0,1,0,2,3,0},//0
		             {0,0,0,0,0,0},//1
		             {0,3,12,0,4,4},//2
		             {0,1,150,2,3,0},//3
		             {0,2,20,0,0,0, 0,4,10,0,1,1},//4
		             {0,4,8,0,7,2,  0,4,8,0,8,3},//5
		             {0,2,-100,0,0,0},//6
		             {0,2,-100,0,0,1},//7
		             {0,2,100,0,0,0},//8
		             {1,2,50,0,0,0},//9
		             {0,1,100,2,3,0, 1,3,25,0,0,0},//10
		             {0,2,100,0,0,1},//11
		             {0,1,100,2,3,0},//
		             {0,2,60,0,0,0, 0,4,10,0,5,5, 0,2,100,0,0,1},		    
		             {0,2,200,0,0,0, 0,4,70,0,1,1, 1,2,100,0,0,1},//
		             {0,2,4,0,0,4},//
		             {0,1,5,4,4,2},//
		             {0,4,-10,0,2,2, 0,4,-10,0,3,3, 0,4,-10,0,4,4},//
		             {0,4,12,0,7,2},//
		             {0,4,12,0,8,3},//
		             {0,1,40,2,3,0},//
		             {0,1,80,0,5,0, 1,3,-75,0,0,0},//
		             {0,4,25,0,2,2, 0,4,25,0,3,3, 1,3,100,2,0,2, 1,3,100,3,0,3},//
		             {0,4,-12,0,0,0, 1,3,100,0,0,0},//
		             {0,2,2147483647,0,0,1},//
		             {0,1,400,2,3,0},//
		             {0,1,80,2,3,0},//
		             {0,4,10,0,3,3},
		             {0,1,100,2,3,0},//
		             {0,1,100,2,3,0},//
		             {1,4,-15,0,9,5},//
		             {0,2,-300,0,0,0}};//	   
		   return r;              
		  }
}
