import java.util.ArrayList;

public abstract class Fighter {

	private final String[] StatNames =          {"HP","Charge","Attack","Defense","Speed"};
    protected ArrayList<Integer> Moveset; 
    protected static ArrayList<Integer> Inventory;
    protected int[] Stats;
    protected Move NextAttack;
    protected int Target;
	protected String Name; 
    public Fighter(String n,int[] s, ArrayList<Integer> m, ArrayList<Integer> in)
    {
        Stats = s;
        Moveset = m;
        Inventory = in;
		  Name = n;
    }
    abstract void choose(String[] p,String c,int b);        
    public static ArrayList<Integer> getInventory()
    {
    		return Inventory;
    }
    public int affect(int e,int i)
    {                          
      if(NextAttack instanceof Guard)
      {
        e = e/2;
      }
      Stats[i] = Stats[i] - e;
      if(Stats[i] < Stats[i]/4 && i>1)
      {
        System.out.println(StatNames[i] + " can not go any lower!");
        Stats[i] = Stats[i+5]/4;
      }
      else if(Stats[i] > Stats[i+5] && i == 0)
      {          
        Stats[i] = Stats[i+5];
        System.out.println(StatNames[i] + " is maxed out");
      }
      else
      {
        if(e > 0)
        {
          System.out.println(Name + " lost " + e +" "+ StatNames[i]);
        }
        else if(e < 0)
        {
          System.out.println(Name + " gained " + -e +" "+ StatNames[i]); 
        }
       
      }
      return e; 
    }
    public String getName()
    {
    	
    	return Name;
    }
    public void reset()
    {
      for(int i=1;i<5;i++)
      {
        Stats[i] = Stats[i+5];
      }
      NextAttack = MovePool.getMove(0);
    }    
    public void setCharge(int i)
    {    	
    	Stats[1] = Stats[1] - i;
    }
    public int getStat(int i)
    {    
        return Stats[i];    
    }
    public Move getNextAtt()
    {    
        return NextAttack;        
    }
    public int getTarget()
    {
        return Target;        
    }  
    public void Charge()
    {     
        Stats[1] = Stats[1] + Stats[4];   
    }      
}


