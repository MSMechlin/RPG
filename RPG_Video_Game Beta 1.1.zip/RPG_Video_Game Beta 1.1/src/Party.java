import java.util.ArrayList;


public class Party {
	private int l;
	private int[] BaseParty;
    private ArrayList<Fighter> Available = new ArrayList<Fighter>();    
    public Party(int[] a)
    {      
       BaseParty = a;
       for(int i = 0; i < a.length;i++)
        {
 			Available.add(FightClub.getFighter(a[i]));
        }
            
        
        
    } 
    
    public void load(int[] f)
    {         
    
    	System.out.print("You are confronted by ");
    	  for(int i =0;i<f.length;i++)
    	  {	  
    		  
    		  if(i == 0)
    		  {
    			  	System.out.print(FightClub.getFighter(f[i]).getName());
    		  }
    		  else if(i == 1)
    		  {
    			  System.out.print(" and his goons");
    		  }
    		  Available.add(FightClub.getFighter(f[i]));
    		  
    	  }
    	  	System.out.println("!");
    	  	
    }
    public void unload(int i)
    {
        Available.remove(i);
    }
    public void Reset()
    {
    		for(Fighter f: Available)
    		{
    			f.reset();
    		}    	
    }
    public void Heal()
    {
    		Available.clear();
    		for(int i = 0;i< BaseParty.length;i++)
    		{
    			Available.add(FightClub.getFighter(BaseParty[i]));
    		}
    }
    public void induct(int a)
    {
    		int[] r = new int[BaseParty.length+1];
    		for(int i = 0; i <= BaseParty.length;i++)
    		{
    			if(i == BaseParty.length)
    				r[i] = a;
    			else
    			r[i] = BaseParty[i];
    		
    		}
    		Available.add(FightClub.getFighter(a));
    }
    public boolean Battle(int[] e)
    { 
      
      load(e);
      
      Reset();
      int s = Available.size();
      boolean b = false;
      boolean a = Tally();
     
      while(a)
      {
        for(int i = 0;i<Available.size();i++)
        {
          
          
          if(Available.get(i).getStat(1) >=  Available.get(i).getNextAtt().getCapacity() && a)
          {
            if(b)
            {             
              exchange(i,Available.get(i).getTarget());              
            }          
            a = Tally();
            if(a)
            {
            		Available.get(i).setCharge(Available.get(i).getNextAtt().getCapacity());                     		
            		
            		Available.get(i).choose(Targets(),showCharge(),l);
            }
            
            if(s > Available.size())
            {
              i = 0;
              s = Available.size();
            }
          }
           
        }
        b = true;
        allCharge();
        
      }       
      if(Available.get(0) instanceof Enemy)
      {
       return false;
      }
      else
      {
        return true;
      }         
    }
    
    public String[] Targets()
    {
      String[] t = new String[Available.size()];
      int i = 0;
      for(Fighter f:Available)
      {
        t[i] = f.getName();
        i++;
      }
      return t;
    }
    public boolean Tally()
    {
      boolean a = false;
      boolean b = false;
      for(int i = 0;i< Available.size();i++)
      {
        if(Available.get(i).getStat(0) <= 0)
        {
        System.out.println(Available.get(i).getName() + " hit the floor!");  
        	Available.remove(i);
          
        } 
      }
      l = 0;
      for(Fighter f: Available)
      {         
        if(f instanceof Ally)
        {
          a = true;
          l++;
        }
        else if(f instanceof Enemy)
        {
          b = true;
        }
      }
      return(a&&b);
    }
    public void allCharge()
    {
      for(Fighter f:Available)
      {
        f.Charge();
      }      
    }
    public String showCharge()
    {
    		String p = "";	
    		for(Fighter f:Available)
    		{
    			p = p + (f.getName() + " Charge: " + f.getStat(1) + "/" + f.getNextAtt().getCapacity() + "  ");
    		}
    		return p;
    		
    }
    public void exchange(int u,int t)
    {
      int[] a = {0,0,0,0,0,0};
      int[][] ins = Available.get(u).getNextAtt().getIns();       
      System.out.println(Available.get(u).getName() + " used " + Available.get(u).getNextAtt().getName());
      
      for(int i=0;i<ins.length;i++)
      {          
        if(ins[i][0] == 0)
        {
        a[ins[i][5]] += Available.get(t).affect(Utility.getOps(ins[i][1]).calculate((ins[i][2]),Available.get(u).getStat(ins[i][3]),Available.get(t).getStat(ins[i][4])),ins[i][5]);
        }          
      }           
      System.out.println(Available.get(t).getName() + Available.get(u).getNextAtt().getScript());
      
    
      for(int i=0;i<ins.length;i++)
      {
        if(ins[i][0] == 1)
        {
          Available.get(u).affect(Utility.getOps(ins[i][1]).calculate(ins[i][2],a[ins[i][5]],Available.get(u).getStat(ins[i][3])),ins[i][5]);
        }              
      } 
      
    }
}
