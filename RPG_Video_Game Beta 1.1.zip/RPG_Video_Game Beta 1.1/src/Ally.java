
import java.util.ArrayList;
import java.util.Scanner;

public class Ally extends Fighter{
  
	    private static Scanner scan = new Scanner(System.in);       
	    public Ally(String n,int[] s,ArrayList<Integer> m,ArrayList<Integer>in)
	    {
	        super(n,s,m,in);           
	    }    
	    public void choose(String[] p,String a,int b)
	    {
	      int c = 0;
	      int c2 = 0;
	      boolean v = false;     
	      		while(v == false)
	            {    
	                System.out.println(a);
	      			System.out.println("What will " + Name + " do?");
	                System.out.println("HP: " + Stats[0] + " Speed: " + Stats[4]);
	                System.out.println("0. Bash  1. Guard  2. Special Attack 3. Item");
	                c = scan.nextInt()%4;                                                               
	                if(c<2)
	                {
	                	v = true;
	                }              
	                else if(c == 2)
	                {
	                    MovePool.setPrint(Moveset);
	                    c = Moveset.get(scan.nextInt() % Moveset.size());
	                    v = true;
	                          
	                }
	                else 
	                {
	                    MovePool.setPrint(Inventory);
	                	c = Inventory.get(scan.nextInt() % Moveset.size());
	                	v = true;
	                }
	            }    
	                    
	            Utility.arrPrint(p);
	            c2 = scan.nextInt() % p.length;                                                                                                     
	        if(c == 1)
	        {
	         NextAttack = new Guard("Guard",MovePool.getMove(c).getIns(),0,"is no longer being stared at.");
	        	  System.out.println("How long?");
	          c = scan.nextInt();
	          System.out.println(c);
	          NextAttack.initiate(c,Stats[4]);
	        }
	        else if(c == 0)
	        {
	        	NextAttack = new Bash("Bash",MovePool.getMove(c).getIns(),0,"was hit.");
	      	  System.out.println("How long?");
	        c = scan.nextInt();
	        System.out.println(c);
	        NextAttack.initiate(c,Stats[4]);
	        }
	        else
	        {
	        		NextAttack = MovePool.getMove(c);
	        }	
	        if(NextAttack instanceof Item)
	        {
	          Inventory.remove(Inventory.indexOf(c));
	        }
	        Target = c2;                  
	    }    
	}


